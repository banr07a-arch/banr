import { backend, live } from "./backend.js";
const icons={
 home:'<path d="m3 10 9-7 9 7v10h-6v-7H9v7H3z"/>',
 ticket:'<path d="M3 5h18v4a3 3 0 0 0 0 6v4H3v-4a3 3 0 0 0 0-6z"/><path d="M14 8h.01m0 4h.01m0 4h.01"/>',
 calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 11h18m-13 4h.01m4 0h.01m4 0h.01"/>',
 user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v2z"/>',
 bell:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-8 12a2 2 0 0 0 4 0"/>',
 pin:'<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/>',
 search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 5 5"/>',
 chevron:'<path d="m9 5 7 7-7 7"/>',down:'<path d="m6 9 6 6 6-6"/>',back:'<path d="m15 5-7 7 7 7"/>',
 general:'<path d="M5 3v6a5 5 0 0 0 10 0V3M3 3h4m6 0h4m-7 11v3a4 4 0 0 0 8 0v-2"/><circle cx="18" cy="12" r="2"/>',
 dentist:'<path d="M12 5c-3-4-9-1-8 4 .3 2 2 3 2 7 0 3 1 5 3 5 1-1 1-6 3-6s2 5 3 6c2 0 3-2 3-5 0-4 1.7-5 2-7 1-5-5-8-8-4z"/>',
 check:'<path d="m5 12 4 4L19 6"/>'
};
const icon=(name,kind="")=>'<svg class="icon '+kind+'" viewBox="0 0 24 24" aria-hidden="true">'+icons[name]+'</svg>';
let facilities=live?[]:[
 {id:"raj",name:"Raj Clinic",type:"Clinic",distance:"1.2 km",hours:"9:00 AM – 8:00 PM",img:"clinic",area:"Andheri East, Mumbai",doctors:[{name:"Dr. Rahul Sharma",specialty:"General Physician",fee:500},{name:"Dr. Kavya Mehta",specialty:"Dentist",fee:650}]},
 {id:"aman",name:"Aman Hospital",type:"Hospital",distance:"2.8 km",hours:"24 × 7",img:"hospital",area:"Vile Parle East, Mumbai",doctors:[{name:"Dr. Neha Shah",specialty:"Gynaecologist",fee:750},{name:"Dr. Arjun Rao",specialty:"General Surgeon",fee:800}]}
];
const demoSessions=[{name:"Morning",hours:"9:30 AM – 12:30 PM"},{name:"Evening",hours:"5:00 PM – 8:00 PM"}];
const screen=document.getElementById("screen");
const topbar=document.getElementById("top");
const nav=document.getElementById("navigation");
const esc=value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
const load=(key,fallback)=>{try{return JSON.parse(localStorage.getItem("banr.demo."+key))??fallback}catch{return fallback}};
const save=(key,value)=>{try{localStorage.setItem("banr.demo."+key,JSON.stringify(value))}catch{}};
let profile=live?null:load("profile",null),bookings=live?[]:load("bookings",[]),phone=live?"":load("phone",""),locationName=load("location","Mumbai");
let user=null, availableSessions=[], busy=false, loadError="", catalogError="", accountError="", queueError="", scheduleLoading=false, scheduleRequest=0;
const formatTime=value=>new Intl.DateTimeFormat("en-IN",{hour:"numeric",minute:"2-digit",timeZone:"Asia/Kolkata"}).format(new Date(value));
const dateKey=value=>new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata"}).format(new Date(value));
const active=b=>!live||(!["completed","no_show","cancelled"].includes(b.status)&&b.opd_status!=="closed"&&Date.parse(b.ends_at)>Date.now());
const sessionOptions=()=>live?availableSessions.filter(s=>dateKey(s.starts_at)===selected.date):demoSessions;
const sessionHours=s=>live?formatTime(s.starts_at)+" – "+formatTime(s.ends_at):s.hours;
const available=s=>!live||s.booked_count<s.capacity;
const waitEstimate=b=>{
 if(!live){
  const ahead=Math.max(0,b.token-b.current-1);
  return {ahead,minutes:b.current>=b.token?0:ahead*3+2};
 }
 if(b.status==="serving")return {ahead:0,minutes:0};
 const start=b.opd_status==="late"?b.revised_start_at:b.starts_at;
 const remaining=b.opd_status==="scheduled"||b.opd_status==="late"
  ? (start?Math.max(0,(Date.parse(start)-Date.now())/60000):null)
  : b.current_started_at ? Math.max(0,b.consultation_minutes-(Date.now()-Date.parse(b.current_started_at))/60000) : 0;
 return {ahead:b.patients_ahead,minutes:b.opd_status==="paused"||remaining==null?null:Math.ceil(remaining+b.patients_ahead*b.consultation_minutes)};
};
let page="home",previous=[],selected={},activeBooking=null,authReturn="details",pendingPhone="",query="",category="",historyTab="upcoming";
let walkInFacility=new URLSearchParams(location.search).get("facility");
const facility=()=>facilities.find(item=>item.id===selected.facility);
const doctor=()=>facility()?.doctors[selected.doctor];
const appointments=()=>!phone?[]:live?bookings:bookings.filter(b=>b.phone===phone);
const walkins=()=>appointments().filter(b=>b.facility===walkInFacility&&b.source==="walkin"&&active(b));
const dayKey=(offset=0)=>new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata"}).format(new Date(Date.now()+86400000*offset));
const prettyDay=date=>new Intl.DateTimeFormat("en-IN",{weekday:"short",day:"numeric",month:"short",timeZone:"Asia/Kolkata"}).format(new Date(date+"T12:00:00+05:30"));
const pageTitle=title=>'<h1 class="pagehead" tabindex="-1">'+esc(title)+'</h1>';
const btn=(label,action,cls="primary")=>'<button type="button" class="'+cls+'" data-action="'+action+'">'+label+'</button>';
const demo='<p class="notice">Interactive demo · sample clinics and queues. Use sample details only.</p>';
const images={
 hero:new URL("./assets/hero.webp",import.meta.url).href,
 clinic:new URL("./assets/clinic.webp",import.meta.url).href,
 hospital:new URL("./assets/hospital.webp",import.meta.url).href
};
const image=(name,alt)=>'<img src="'+images[name]+'" alt="'+alt+'">';
function go(next,reset=false){
 if(reset) previous=[]; else if(page!==next) previous.push(page);
 page=next;
 render();
 scrollTo(0,0);
 screen.querySelector("h1")?.focus({preventScroll:true});
}
function shell(){
 topbar.innerHTML=(previous.length?btn(icon("back"),"back","iconbtn"):"<span></span>")+
 '<div><div class="brand">BANR</div><div class="subtitle">Save Your Time</div></div>'+
 '<button class="iconbtn" type="button" data-action="notifications" aria-label="Notifications">'+icon("bell")+'</button>';
 topbar.querySelector('[data-action=back]')?.setAttribute("aria-label","Go back");
 const current=["token","appointments","account"].includes(page)?page:"home";
 nav.innerHTML=[["home","home","Home"],["token","ticket","My Token"],["appointments","calendar","Appointments"],["account","user","Account"]].map(([id,img,label])=>
 '<button type="button" data-action="nav:'+id+'" '+(current===id?'aria-current="page"':'')+'>'+icon(img)+label+'</button>').join("");
}
function card(item){
 return '<button class="facility raised" data-action="facility:'+item.id+'"><figure>'+image(item.img,"")+'</figure><div><h3>'+esc(item.name)+'</h3><p>'+esc(item.distance||item.area)+' · '+esc(item.hours)+'</p><span class="tag">'+esc(item.doctors.map(d=>d.specialty).join(", "))+'</span></div>'+icon("chevron","chev")+'</button>';
}
function results(){
 if(catalogError)return '<p class="panel raised" role="alert">'+esc(catalogError)+'</p>'+btn("Retry","retry-catalog","link");
 if(live&&!facilities.length)return '<p class="panel raised">No facilities are listed yet.</p>';
 const value=query.trim().toLowerCase();
 const matches=facilities.filter(f=>{
 const haystack=[f.name,f.area,f.type,...f.doctors.flatMap(d=>[d.name,d.specialty])].join(" ").toLowerCase();
 return (!category||haystack.includes(category.toLowerCase()))&&(!value||haystack.includes(value))&&(!live||f.area.toLowerCase().includes(locationName.toLowerCase())||f.address.toLowerCase().includes(locationName.toLowerCase()));
 });
 if(value||category) return '<div class="sectionhead"><h2>'+(esc(category)||"Search results")+'</h2>'+btn("Clear","clear","link")+'</div>'+
 (matches.length?matches.map(card).join(""):'<p class="panel raised">No clinics or hospitals match your search.</p>');
 return [["Clinic","Nearest Clinic"],["Hospital","Nearest Hospital"]].map(([type,title])=>
 '<div class="sectionhead"><h2>'+title+'</h2>'+btn("View More","filter:"+type,"link")+'</div>'+(matches.filter(f=>f.type===type).map(card).join("")||'<p class="small">No listings in this area.</p>')).join("");
}
function home(){
 return '<div class="intro row"><h1 tabindex="-1">Home</h1>'+btn(icon("pin")+esc(locationName)+icon("down"),"location","place raised")+'</div>'+
 '<label class="search raised">'+icon("search")+'<input id="search" type="search" aria-label="Search doctors, clinics and hospitals" value="'+esc(query)+'" placeholder="Search doctors, clinics, hospitals…"></label>'+
 '<section class="hero">'+image("hero","")+'<h2>Skip the Wait,<br>Book Your OPD<br>with <strong>BANR</strong></h2><p>✓ Live Token &nbsp; ✓ Wait Time &nbsp; ✓ Easy Booking</p></section><div class="dots" aria-hidden="true"><i></i><i></i><i></i></div>'+
 '<div class="sectionhead"><h2>Find Doctor by Specialist</h2>'+btn("View All","specialties","link")+'</div>'+
 '<div class="specials">'+[["General","general","General"],["Physician","user","Physician"],["Dentist","dentist","Dentist"],["Gynae","user","Gynae"]].map(([label,img,value])=>btn(icon(img)+label,"filter:"+value,"tile raised")).join("")+'</div>'+
 '<div id="results">'+results()+'</div>'+(live?'':demo);
}
function detail(){
 const f=facility();
 const directions=live?'<a class="link" target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(f.latitude!=null&&f.longitude!=null?f.latitude+","+f.longitude:f.address)+'">Get Directions</a>':"";
 return pageTitle(f.name)+'<div class="panel raised stack"><div class="photo">'+image(f.img,"")+'</div><p>'+esc(live?f.address:f.area+" · "+f.distance)+'</p><p>'+esc(f.hours)+'</p>'+directions+'</div><h2>Doctors at '+esc(f.name)+'</h2>'+
 f.doctors.map((d,i)=>'<article class="panel raised stack"><h3>'+esc(d.name)+'</h3><p class="subtle">'+esc(d.specialty)+' · ₹'+d.fee+'</p>'+btn("Book Appointment","book:"+i)+'</article>').join("");
}
function schedule(){
 const dates=live?[...new Set(availableSessions.map(s=>dateKey(s.starts_at)))]:[0,1,2,3].map(dayKey);
 const sessionList=sessionOptions();
 const body=scheduleLoading?'<p>Loading OPD sessions…</p>':loadError?'<p role="alert">'+esc(loadError)+'</p>'+btn("Retry","retry-schedule","link"):
 !dates.length?'<p>No upcoming sessions for this doctor.</p>':
 '<div><h3>Choose a date</h3><div class="chips">'+dates.map(date=>'<button class="chip" data-action="date:'+date+'" aria-pressed="'+(selected.date===date)+'">'+prettyDay(date)+'</button>').join("")+'</div></div>'+
 '<div><h3>Choose a session</h3><div class="stack">'+sessionList.map((s,i)=>'<button class="chip" data-action="session:'+i+'" aria-pressed="'+(selected.session===i)+'" '+(available(s)?'':'disabled')+'>'+s.name+' · '+sessionHours(s)+(available(s)?'':' · Fully Booked')+'</button>').join("")+'</div></div>'+
 '<button class="primary full" data-action="continue" '+(selected.session==null?"disabled":"")+'>Continue</button>';
 return pageTitle("Book Appointment")+'<div class="panel raised stack"><h2>'+esc(doctor().name)+'</h2><p>'+esc(facility().name)+' · ₹'+doctor().fee+'</p>'+body+'</div>';
}
async function openSchedule(){
 const request=++scheduleRequest;
 loadError="";
 availableSessions=[];
 scheduleLoading=live;
 selected.session=null;
 go("schedule");
 if(!live)return;
 try{
  const sessions=await backend.sessions(doctor().id);
  if(request!==scheduleRequest)return;
  availableSessions=sessions;
  selected.date=sessions.length?dateKey(sessions[0].starts_at):"";
 }catch{
  if(request===scheduleRequest)loadError="Could not load OPD sessions.";
 }finally{
  if(request===scheduleRequest){scheduleLoading=false;if(page==="schedule")render();}
 }
}
function login(){
 return pageTitle(pendingPhone?"Verify mobile number":"Mobile OTP Login")+
 '<form class="panel raised stack" data-form="otp">'+
 (pendingPhone?'<p>Verifying +91 '+esc(pendingPhone)+'</p><label class="field">OTP<input name="otp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required></label>'+(live?'':'<p class="notice">Demo OTP is <strong>123456</strong>. No SMS is sent.</p>'):
 '<label class="field">Mobile number (+91)<input name="phone" inputmode="numeric" autocomplete="tel-national" pattern="[0-9]{10}" maxlength="10" required></label>'+(live?'':'<p class="notice">Use 9000000017 to try the sample walk-in, or enter any fictional 10-digit number.</p>'))+
 '<p class="err" id="form-error" role="alert"></p><button class="primary" type="submit">'+(pendingPhone?"Verify & Continue":live?"Send OTP":"Get Demo OTP")+'</button>'+
 (pendingPhone?btn("Change Number","change-number","link"):"")+'</form>';
}
function profileFields(){
 const details=profile?.phone===phone?profile:{};
 return '<label class="field">Name<input name="name" autocomplete="name" required maxlength="80" value="'+esc(details.name)+'"></label>'+
 '<label class="field">Age<input name="age" type="number" required min="0" max="120" value="'+esc(details.age)+'"></label>'+
 '<label class="field">Sex<select name="sex" required><option value="">Select</option>'+["Female","Male","Intersex","Prefer not to say"].map(s=>'<option '+(details.sex===s?"selected":"")+'>'+s+'</option>').join("")+'</select></label>'+
 '<label class="field">Verified mobile number<input value="+91 '+esc(phone)+'" readonly></label>';
}
function details(){
 const session=sessionOptions()[selected.session];
 return pageTitle("Confirm Patient Details")+'<form class="panel raised stack" data-form="booking">'+profileFields()+
 '<div class="notice"><strong>'+esc(doctor().name)+'</strong><br>'+esc(facility().name)+' · '+prettyDay(selected.date)+'<br>'+session.name+' · '+sessionHours(session)+' · ₹'+doctor().fee+'</div>'+
 '<p class="err" id="form-error" role="alert"></p><button class="primary" type="submit">Confirm Booking</button></form>';
}
const tokenLabel=token=>"#"+String(token).padStart(2,"0");
function confirm(){
 const b=activeBooking;
 const {minutes}=waitEstimate(b);
 return pageTitle("Booking Confirmed")+'<div class="panel raised stack"><p>'+icon("check")+' Your Token</p><div class="number">'+tokenLabel(b.token)+'</div><h2>'+esc(b.doctor)+'</h2><p>'+esc(b.facilityName)+' · '+prettyDay(b.date)+'<br>'+b.sessionName+'</p>'+
 (minutes==null?'':'<p>Estimated consultation at <strong>'+formatTime(Date.now()+minutes*60000)+'</strong></p>')+
 btn("Track My Token","track:"+b.id)+'</div>';
}
function token(){
 const all=appointments().filter(active);
 const b=all.find(item=>item.id===activeBooking?.id)??all[0];
 if(!b) return pageTitle("My Token")+'<div class="panel raised stack"><h2>No active token</h2><p>Open an active appointment to see your token.</p>'+btn("Find a Doctor","nav:home")+(live?(phone?'':btn("Mobile OTP Login","login:token","link")):btn("Try Walk-in Tracking","walkin:raj","link"))+'</div>';
 const nowServing=b.opd_status==="paused"||!b.current?null:b.current;
 const {ahead,minutes}=waitEstimate(b);
 const status=b.opd_status==="paused"?"OPD paused · Timing update pending":
  b.opd_status==="late"?"Doctor running late"+(b.revised_start_at?" · Revised start "+formatTime(b.revised_start_at):""):
  b.opd_status==="scheduled"?"OPD yet to start · "+formatTime(b.starts_at):
  b.status==="serving"||(!live&&b.current>=b.token)?"Your turn now. Please report to reception.":
  minutes!=null&&minutes<=5?"Your turn is near. Please be ready.":"";
 return pageTitle("My Token")+(all.length>1?'<label class="field">Select appointment<select id="active-booking">'+all.map(item=>'<option value="'+item.id+'" '+(item.id===b.id?"selected":"")+'>'+esc(item.doctor)+' · '+tokenLabel(item.token)+'</option>').join("")+'</select></label>':"")+
 '<section class="panel raised stack">'+(live?'':'<p class="tag">Demo queue</p>')+'<h2>'+esc(b.doctor)+'</h2><p>'+esc(b.facilityName)+' · '+b.sessionName+' OPD</p>'+
 '<div class="numbers"><div class="stat"><p>Now Serving</p><div class="number">'+(nowServing==null?"—":tokenLabel(nowServing))+'</div></div><div class="stat"><p>Your Token</p><div class="number">'+tokenLabel(b.token)+'</div></div></div>'+
 (status?'<p><strong>'+status+'</strong></p>':'')+
 (minutes!=null&&b.status!=="serving"&&(live||b.current<b.token)?'<p><strong>'+ahead+'</strong> patients ahead</p><p>Estimated wait <strong>'+minutes+' min</strong><br>Suggested arrival <strong>'+formatTime(Date.now()+Math.max(0,minutes-5)*60000)+'</strong></p>':'')+
 (live?(queueError?'<p role="alert" class="notice">'+esc(queueError)+'</p>':''):btn("Advance Demo Queue","advance:"+b.id,"link"))+'</section>';
}
function appointmentPage(){
 const list=appointments().filter(b=>active(b)===(historyTab==="upcoming"));
 return pageTitle("Appointments")+'<div class="chips">'+["upcoming","past"].map(tab=>'<button class="chip" data-action="history:'+tab+'" aria-pressed="'+(historyTab===tab)+'">'+(tab==="upcoming"?"Upcoming":"Past")+'</button>').join("")+'</div>'+
 (accountError?'<p class="notice" role="alert">'+esc(accountError)+'</p>':'')+
 (list.length?list.map(b=>'<article class="panel raised stack"><h2>'+esc(b.doctor)+'</h2><p>'+esc(b.facilityName)+' · '+prettyDay(b.date)+' · '+b.sessionName+'</p><p class="tag">Token '+tokenLabel(b.token)+'</p>'+(
 active(b)?btn("Track Token","track:"+b.id):'<p>'+({completed:"Completed",no_show:"No Show",cancelled:"Cancelled"}[b.status]||"Session ended")+'</p>')+'</article>').join(""):'<div class="panel raised stack"><p>No '+historyTab+' appointments.</p>'+(!phone&&live?btn("Mobile OTP Login","login:appointments"):btn("Find a Doctor","nav:home"))+'</div>');
}
function account(){
 return pageTitle("Account")+(accountError?'<p role="alert" class="notice">'+esc(accountError)+'</p>':'')+(phone?'<form class="panel raised stack" data-form="profile">'+profileFields()+'<p class="err" id="form-error" role="alert"></p><button class="primary" type="submit">Save Profile</button>'+btn("Sign Out","signout","link")+'</form>':
 '<div class="panel raised stack"><p>Verify your mobile number to manage your patient profile and bookings.</p>'+btn("Mobile OTP Login","login:account")+'</div>');
}
function walkin(){
 const f=facilities.find(f=>f.id===walkInFacility);
 const found=walkins();
 return pageTitle("Walk-in Tracking")+'<div class="panel raised stack"><h2>'+esc(f?.name||"Facility")+'</h2>'+
 (found.length?found.map(b=>btn(esc(b.doctor)+" · "+tokenLabel(b.token),"track:"+b.id)).join(""):phone?
 '<p>No active walk-in appointment found for this number.</p>'+btn("Try Another Number","login:walkin"):
 '<p>Verify the mobile number you gave at reception to open your token.</p>'+btn("Verify Mobile Number","login:walkin"))+'</div>';
}
function render(){
 shell();
 const pages={home,facility:detail,schedule,login,details,confirm,token,appointments:appointmentPage,account,walkin,
 location:()=>pageTitle("Change Location")+'<form class="panel raised stack" data-form="location"><label class="field">Area or city<input name="area" maxlength="45" value="'+esc(locationName)+'" required></label>'+(live?'':'<p class="notice">The sample facility list is fixed in this demo.</p>')+'<button class="primary" type="submit">Save Location</button></form>',
 notifications:()=>pageTitle("Notifications")+'<p class="panel raised">No new notifications.</p>',
 specialties:()=>pageTitle("Specialties")+'<div class="panel raised stack">'+["General","Physician","Dentist","Gynae","Surgery"].map(s=>btn(s,"filter:"+s,"chip")).join("")+'</div>'};
 screen.innerHTML=pages[page]().replaceAll(/<div class="photo"><img /g,'<div><img class="photo" ');
}
document.addEventListener("click",async event=>{
 const control=event.target.closest("[data-action]");
 if(!control||busy)return;
 const [action,value]=control.dataset.action.split(":");
 switch(action){
 case "back":page=previous.pop()??"home";render();scrollTo(0,0);break;
 case "nav":go(value,true);break;
 case "location":case "notifications":case "specialties":go(action);break;
 case "clear":category="";query="";render();document.getElementById("search").focus();break;
 case "filter":category=value;query="";go("home",true);document.getElementById("results").scrollIntoView({block:"center"});break;
 case "facility":selected={facility:value};go("facility");break;
 case "book":selected={facility:selected.facility,doctor:Number(value),date:dayKey()};await openSchedule();break;
 case "retry-schedule":await openSchedule();break;
 case "retry-catalog":await loadCatalog();render();break;
 case "date":selected.date=value;selected.session=null;render();break;
 case "session":selected.session=Number(value);render();break;
 case "continue":phone?go("details"):startLogin("details");break;
 case "login":startLogin(value);break;
 case "change-number":pendingPhone="";render();break;
 case "history":historyTab=value;render();break;
 case "track":activeBooking=appointments().find(b=>b.id===value);go("token");break;
 case "advance":{
  if(live)break;
  const b=appointments().find(item=>item.id===value);
  if(b&&b.current<b.token){b.current++;save("bookings",bookings);render();}
  break;
 }
 case "walkin":walkInFacility=value;go("walkin");break;
 case "signout":
  if(live){
   try{await backend.signOut();clearAccount();}catch{document.getElementById("form-error").textContent="Sign out failed. Try again.";break;}
  }else{phone="";activeBooking=null;save("phone",phone);}
  render();break;
 }
});
function startLogin(returnPage){authReturn=returnPage;pendingPhone="";go("login");}
document.addEventListener("input",event=>{
 if(event.target.id==="search"){query=event.target.value;document.getElementById("results").innerHTML=results();}
});
document.addEventListener("change",event=>{
 if(event.target.id==="active-booking"){activeBooking=appointments().find(b=>b.id===event.target.value);render();}
});
document.addEventListener("submit",async event=>{
 const type=event.target.dataset.form;
 if(!type)return;
 event.preventDefault();
 if(busy)return;
 const data=Object.fromEntries(new FormData(event.target));
 if(type==="location"){locationName=data.area.trim()||"Mumbai";save("location",locationName);go("home",true);return;}
 if(live){await submitLive(type,data,event.target);return;}
 if(type==="otp"){
  if(!pendingPhone){pendingPhone=data.phone;render();screen.querySelector("[name=otp]").focus();return;}
  if(data.otp!=="123456"){document.getElementById("form-error").textContent="Enter the demo code 123456.";return;}
  phone=pendingPhone;pendingPhone="";save("phone",phone);
  if(authReturn==="walkin"&&phone==="9000000017"&&walkInFacility==="raj"&&!bookings.some(b=>b.id==="demo-walkin")){
   bookings.push({id:"demo-walkin",source:"walkin",phone,facility:"raj",facilityName:"Raj Clinic",doctor:"Dr. Rahul Sharma",sessionName:"Evening",date:dayKey(),token:17,current:12});
   save("bookings",bookings);
  }
  const found=appointments().filter(b=>b.facility===walkInFacility&&b.source==="walkin");
  if(authReturn==="walkin"&&found.length===1){activeBooking=found[0];go("token",true);return;}
  go(authReturn);return;
 }
 if(!phone||!data.name.trim())return;
 if(type==="booking"&&appointments().some(b=>b.facility===facility().id&&b.doctor===doctor().name&&b.date===selected.date&&b.sessionName===demoSessions[selected.session].name)){
  document.getElementById("form-error").textContent="You already have this session booked. Open Appointments to track it.";return;
 }
 profile={name:data.name.trim(),age:data.age,sex:data.sex,phone};save("profile",profile);
 if(type==="profile"){go("account",true);screen.querySelector("form").insertAdjacentHTML("beforeend",'<p role="status" class="notice">Profile saved.</p>');return;}
 const existing=bookings.filter(b=>b.facility===facility().id&&b.doctor===doctor().name&&b.date===selected.date&&b.sessionName===demoSessions[selected.session].name);
 const last=existing[existing.length-1];
 activeBooking={id:String(Date.now()),phone,source:"online",facility:facility().id,facilityName:facility().name,doctor:doctor().name,sessionName:demoSessions[selected.session].name,date:selected.date,token:(last?.token??16)+1,current:last?.current??12};
 bookings.push(activeBooking);save("bookings",bookings);go("confirm");
});
function clearAccount(){
 user=null;phone="";profile=null;bookings=[];activeBooking=null;accountError="";queueError="";
}
async function loadCatalog(){
 try{
  const rows=await backend.facilities();
  facilities=rows.map(f=>({...f,img:f.type.toLowerCase()}));
  catalogError="";
 }catch{catalogError="Could not load clinics and hospitals. Please try again.";}
}
async function refreshAppointments(){
 const owner=user?.id;
 if(!owner)return;
 const rows=await backend.appointments();
 if(user?.id!==owner)return;
 bookings=rows.map(b=>({...b,date:dateKey(b.starts_at),facilityName:b.facility_name,sessionName:b.session_name,current:b.current_token}));
}
async function setAccount(nextUser){
 const number=nextUser?.phone?.replace(/^\+?91(?=\d{10}$)/,"");
 if(!nextUser||!/^\d{10}$/.test(number??"")){clearAccount();return;}
 if(user?.id!==nextUser.id)clearAccount();
 user=nextUser;phone=number;
 const [details]=await Promise.all([backend.profile(),refreshAppointments()]);
 if(user?.id===nextUser.id){profile=details?{...details,phone}:null;accountError="";}
}
async function submitLive(type,details,form){
 busy=true;
 const button=form.querySelector("button[type=submit]");
 button.disabled=true;
 const error=form.querySelector("#form-error");
 error.textContent="";
 try{
  if(type==="otp"){
   if(!pendingPhone){
    await backend.sendOtp("+91"+details.phone);
    pendingPhone=details.phone;
    render();
    screen.querySelector("[name=otp]").focus();
    return;
   }
   await setAccount(await backend.verifyOtp("+91"+pendingPhone,details.otp));
   pendingPhone="";
   const found=walkins();
   if(authReturn==="walkin"&&found.length===1){activeBooking=found[0];go("token",true);return;}
   go(authReturn,true);
   return;
  }
  if(!user){startLogin(type==="booking"?"details":"account");return;}
  const fields={name:details.name.trim(),age:Number(details.age),sex:details.sex};
  if(!fields.name){error.textContent="Enter your name.";return;}
  if(type==="profile"){
   await backend.saveProfile(user.id,fields);
   profile={...fields,phone};
   form.insertAdjacentHTML("beforeend",'<p role="status" class="notice">Profile saved.</p>');
   return;
  }
  const id=await backend.book(sessionOptions()[selected.session].id,fields);
  profile={...fields,phone};
  try{await refreshAppointments();}catch{
   accountError="Your booking was saved. Reopen Appointments to load your token.";
   go("appointments",true);
   return;
  }
  activeBooking=appointments().find(b=>b.id===id);
  if(activeBooking)go("confirm",true);else go("appointments",true);
 }catch(err){
  error.textContent=err.message||"Could not complete this request. Please try again.";
 }finally{
  busy=false;
  button.disabled=false;
 }
}
async function start(){
 if(live){
  screen.innerHTML='<p class="panel raised" role="status">Loading BANR…</p>';
  await Promise.all([loadCatalog(),(async()=>{
   try{await setAccount(await backend.currentUser());}
   catch{accountError="Could not load your account. Sign in again if needed.";}
  })()]);
  backend.authChanges(event=>{
   if(event==="SIGNED_OUT"){
    clearAccount();
    if(["confirm","details"].includes(page))go("account",true);else render();
   }
  });
  let refreshing=false;
  setInterval(async()=>{
   if(!user||refreshing||!["token","appointments","walkin"].includes(page)||busy)return;
   refreshing=true;
   try{await refreshAppointments();queueError="";accountError="";}
   catch{queueError="Could not refresh the queue. Showing the last update.";}
   finally{refreshing=false;if(["token","appointments","walkin"].includes(page)&&!busy)render();}
  },5000);
 }
 if((live&&/^[a-z0-9-]+$/.test(walkInFacility??""))||facilities.some(f=>f.id===walkInFacility)){
  page="walkin";
  const found=walkins();
  if(found.length===1){activeBooking=found[0];page="token";}
 }
 render();
}
start();
